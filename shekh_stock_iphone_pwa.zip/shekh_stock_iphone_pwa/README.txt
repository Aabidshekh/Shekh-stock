SHEKH STOCK — iPhone PWA package

This is a Progressive Web App package. To install it on iPhone:
1. Host all files in this folder on an HTTPS website.
2. Open that HTTPS URL in Safari on iPhone.
3. Tap Share > Add to Home Screen > Add.

Important:
- Opening index.html directly from Files is not enough for PWA installation.
- Service workers and installable PWA features require HTTPS (or localhost).
- This is still a front-end demo. It stores demo data locally in the browser and does not yet provide real multi-shop shared database, user accounts, authentication, or cloud sync.
